-- PostgreSQL: el mismo esquema que init-mysql/01-schema.sql.
--
-- Leé los dos archivos en paralelo. Las diferencias están señaladas con
-- "DIFERENCIA" y son exactamente las que te van a morder al pasar de uno al
-- otro.
--
-- Los datos son inventados. Ningún registro clínico real entra acá, igual
-- que en VitaLink.

-- DIFERENCIA 1 — La clave autoincremental.
--   PostgreSQL:  GENERATED ALWAYS AS IDENTITY   (o el viejo SERIAL)
--   MySQL:       AUTO_INCREMENT
--
-- DIFERENCIA 2 — El nombre de la tabla.
--   Lo escribo en minúscula a propósito. PostgreSQL pasa todo identificador
--   sin comillas a minúscula, así que "patient" y patient son la misma
--   tabla. En cambio "Patient" con comillas dobles crea una tabla que a
--   partir de ahí SIEMPRE hay que escribir entre comillas — que es el caso
--   de VitaLink, porque Prisma las creó con mayúscula inicial.
--
-- DIFERENCIA 3 — boolean.
--   PostgreSQL tiene un tipo booleano de verdad. MySQL usa TINYINT(1) y te
--   devuelve 0 y 1.

CREATE TABLE patient (
  id          INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  mrn         VARCHAR(20)  NOT NULL UNIQUE,
  family_name VARCHAR(80)  NOT NULL,
  given_name  VARCHAR(80)  NOT NULL,
  birth_date  DATE         NOT NULL,
  sex         VARCHAR(10)  NOT NULL
);

-- DIFERENCIA 4 — El instante.
--   timestamptz guarda un punto absoluto en el tiempo: se almacena en UTC y
--   se muestra en la zona de la sesión. timestamp a secas guarda una lectura
--   de reloj sin zona, que es ambigua. MySQL tiene DATETIME (sin zona) y
--   TIMESTAMP (que sí convierte, pero con un rango que termina en 2038).
--   VitaLink tiene una migración entera sólo para pasar de timestamp a
--   timestamptz, porque el hospital manda horas locales sin zona.

CREATE TABLE admission (
  id         INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  patient_id INT         NOT NULL REFERENCES patient(id),
  ward       VARCHAR(40) NOT NULL,
  admitted_at TIMESTAMPTZ NOT NULL,
  discharged_at TIMESTAMPTZ,
  diagnosis  VARCHAR(120),
  urgent     BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE TABLE observation (
  id             INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  admission_id   INT         NOT NULL REFERENCES admission(id),
  recorded_at    TIMESTAMPTZ NOT NULL,
  respiration_rate INT,
  oxygen_saturation INT,
  systolic_bp    INT,
  pulse          INT,
  temperature    NUMERIC(4, 1),
  news2          INT
);

-- El índice que hace barata la consulta "la última observación de cada
-- internación": el motor busca por admission_id y ya encuentra las filas
-- ordenadas por fecha, así que tomar la primera es una sola lectura.
CREATE INDEX observation_admission_recorded_idx
  ON observation (admission_id, recorded_at DESC);

INSERT INTO patient (mrn, family_name, given_name, birth_date, sex) VALUES
  ('MRN-001', 'OCASIO',    'Andrés',   '1956-03-11', 'male'),
  ('MRN-002', 'VERGARA',   'Patricia', '1955-07-02', 'female'),
  ('MRN-003', 'ZAYAS',     'David',    '1939-11-24', 'male'),
  ('MRN-004', 'MEDINA',    'Antonia',  '1941-04-24', 'female'),
  ('MRN-005', 'CARRERA',   'Fernando', '1995-01-30', 'male'),
  ('MRN-006', 'BORREGO',   'Yolanda',  '1939-05-09', 'female'),
  ('MRN-007', 'PRADO',     'Vicente',  '1960-08-17', 'male'),
  ('MRN-008', 'GAMBOA',    'Daniela',  '1967-02-05', 'female');

INSERT INTO admission (patient_id, ward, admitted_at, discharged_at, diagnosis, urgent) VALUES
  (1, 'internal-medicine', '2026-09-16 08:00:00+00', NULL,                      'Infeccion urinaria alta',            TRUE),
  (2, 'internal-medicine', '2026-09-18 10:30:00+00', NULL,                      'Estudio de anemia programado',       FALSE),
  (3, 'surgery',           '2026-09-18 14:00:00+00', NULL,                      'Eventracion de pared abdominal',     FALSE),
  (4, 'cardiology',        '2026-09-24 21:15:00+00', NULL,                      'Insuficiencia cardiaca descompensada', TRUE),
  (5, 'surgery',           '2026-09-23 09:00:00+00', NULL,                      'Colecistectomia laparoscopica',      FALSE),
  (6, 'internal-medicine', '2026-09-16 19:45:00+00', NULL,                      'Neumonia adquirida en la comunidad', TRUE),
  (7, 'surgery',           '2026-09-01 08:00:00+00', '2026-09-12 11:00:00+00',  'Colecistectomia laparoscopica',      FALSE),
  (8, 'cardiology',        '2026-09-05 07:30:00+00', '2026-09-09 16:00:00+00',  'Angioplastia coronaria programada',  FALSE);

-- Tres rondas por internación abierta, y una internación sin ninguna
-- observación (la 4) — porque el paciente que nadie midió es justamente el
-- que no puede desaparecer de un tablero, y un LEFT JOIN es lo único que lo
-- deja en la lista.
INSERT INTO observation (admission_id, recorded_at, respiration_rate, oxygen_saturation, systolic_bp, pulse, temperature, news2) VALUES
  (1, '2026-09-25 06:00:00+00', 25, 93, 104,  96, 37.4,  9),
  (1, '2026-09-26 01:00:00+00', 25, 93, 105,  98, 37.2,  9),
  (1, '2026-09-26 20:00:00+00', 24, 94, 107,  97, 36.9, 10),
  (2, '2026-09-25 09:00:00+00', 16, 96, 112,  39, 36.5,  3),
  (2, '2026-09-26 03:00:00+00', 16, 95, 118,  39, 36.7,  4),
  (2, '2026-09-26 22:00:00+00', 14, 96, 124,  39, 36.4,  3),
  (3, '2026-09-25 07:00:00+00', 26, 93, 128,  78, 37.1,  5),
  (3, '2026-09-26 05:00:00+00', 26, 94, 134,  74, 36.7,  4),
  (3, '2026-09-26 23:00:00+00', 26, 94, 127,  73, NULL,  4),
  (5, '2026-09-25 11:00:00+00', 18, 98, 116, NULL, 36.2,  0),
  (5, '2026-09-26 06:00:00+00', 19, 97, 112,  64, 36.4,  0),
  (5, '2026-09-27 00:00:00+00', 18, 98, 118,  69, 36.5,  0),
  (6, '2026-09-25 10:00:00+00', 13, 94, 124,  83, 36.2,  1),
  (6, '2026-09-26 04:00:00+00', 15, 93, 124,  82, 36.3,  2),
  (6, '2026-09-26 21:00:00+00', 15, 95, 129,  76, 36.4,  1);
