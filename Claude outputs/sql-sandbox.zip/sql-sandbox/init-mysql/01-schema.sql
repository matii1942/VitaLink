-- MySQL: el mismo esquema que init-postgres/01-schema.sql.
--
-- Leelos en paralelo. Las cuatro diferencias señaladas en el archivo de
-- PostgreSQL son éstas, del otro lado.
--
-- Los datos son inventados. Ningún registro clínico real entra acá.

-- DIFERENCIA 1 — AUTO_INCREMENT en lugar de GENERATED ALWAYS AS IDENTITY.
-- DIFERENCIA 2 — Acá no hay drama de mayúsculas al leer, pero sí hay una
--   trampa distinta: en Linux los nombres de tabla de MySQL SON sensibles a
--   mayúsculas, y en Windows y macOS no. El mismo código anda en tu máquina
--   y falla en el servidor. La costumbre sana, en las dos bases, es escribir
--   todo en minúscula_con_guion_bajo y no pensar nunca más en esto.
-- DIFERENCIA 3 — BOOLEAN existe como palabra, pero es un alias de
--   TINYINT(1): te va a devolver 0 y 1, no false y true.
-- DIFERENCIA 4 — DATETIME no guarda zona horaria. Es lo más parecido al
--   timestamp SIN zona de PostgreSQL, que es justamente el que VitaLink
--   dejó de usar.

CREATE TABLE patient (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  mrn         VARCHAR(20)  NOT NULL UNIQUE,
  family_name VARCHAR(80)  NOT NULL,
  given_name  VARCHAR(80)  NOT NULL,
  birth_date  DATE         NOT NULL,
  sex         VARCHAR(10)  NOT NULL
);

CREATE TABLE admission (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  patient_id    INT         NOT NULL,
  ward          VARCHAR(40) NOT NULL,
  admitted_at   DATETIME    NOT NULL,
  discharged_at DATETIME    NULL,
  diagnosis     VARCHAR(120),
  urgent        BOOLEAN     NOT NULL DEFAULT FALSE,
  FOREIGN KEY (patient_id) REFERENCES patient(id)
);

CREATE TABLE observation (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  admission_id      INT      NOT NULL,
  recorded_at       DATETIME NOT NULL,
  respiration_rate  INT,
  oxygen_saturation INT,
  systolic_bp       INT,
  pulse             INT,
  temperature       DECIMAL(4, 1),
  news2             INT,
  FOREIGN KEY (admission_id) REFERENCES admission(id)
);

CREATE INDEX observation_admission_recorded_idx
  ON observation (admission_id, recorded_at DESC);

INSERT INTO patient (mrn, family_name, given_name, birth_date, sex) VALUES
  ('MRN-001', 'OCASIO',    'Andrés',   '1956-03-11', 'male'),
  ('MRN-002', 'VERGARA',   'Patricia', '1955-07-02', 'female'),
  ('MRN-003', 'ZAYAS',     'David',    '1939-11-24', 'male'),
  ('MRN-004', 'MEDINA',    'Antonia',  '1941-04-24', 'female'),
  ('MRN-005', 'CARRERA',   'Fernando', '1995-01-30', 'male'),
  ('MRN-006', 'BORREGO',   'Yolanda',  '1939-05-09', 'female'),
  ('MRN-007', 'PRADO',     'Vicente',  '1960-08-17', 'male'),
  ('MRN-008', 'GAMBOA',    'Daniela',  '1967-02-05', 'female');

INSERT INTO admission (patient_id, ward, admitted_at, discharged_at, diagnosis, urgent) VALUES
  (1, 'internal-medicine', '2026-09-16 08:00:00', NULL,                  'Infeccion urinaria alta',              TRUE),
  (2, 'internal-medicine', '2026-09-18 10:30:00', NULL,                  'Estudio de anemia programado',         FALSE),
  (3, 'surgery',           '2026-09-18 14:00:00', NULL,                  'Eventracion de pared abdominal',       FALSE),
  (4, 'cardiology',        '2026-09-24 21:15:00', NULL,                  'Insuficiencia cardiaca descompensada', TRUE),
  (5, 'surgery',           '2026-09-23 09:00:00', NULL,                  'Colecistectomia laparoscopica',        FALSE),
  (6, 'internal-medicine', '2026-09-16 19:45:00', NULL,                  'Neumonia adquirida en la comunidad',   TRUE),
  (7, 'surgery',           '2026-09-01 08:00:00', '2026-09-12 11:00:00', 'Colecistectomia laparoscopica',        FALSE),
  (8, 'cardiology',        '2026-09-05 07:30:00', '2026-09-09 16:00:00', 'Angioplastia coronaria programada',    FALSE);

INSERT INTO observation (admission_id, recorded_at, respiration_rate, oxygen_saturation, systolic_bp, pulse, temperature, news2) VALUES
  (1, '2026-09-25 06:00:00', 25, 93, 104,  96, 37.4,  9),
  (1, '2026-09-26 01:00:00', 25, 93, 105,  98, 37.2,  9),
  (1, '2026-09-26 20:00:00', 24, 94, 107,  97, 36.9, 10),
  (2, '2026-09-25 09:00:00', 16, 96, 112,  39, 36.5,  3),
  (2, '2026-09-26 03:00:00', 16, 95, 118,  39, 36.7,  4),
  (2, '2026-09-26 22:00:00', 14, 96, 124,  39, 36.4,  3),
  (3, '2026-09-25 07:00:00', 26, 93, 128,  78, 37.1,  5),
  (3, '2026-09-26 05:00:00', 26, 94, 134,  74, 36.7,  4),
  (3, '2026-09-26 23:00:00', 26, 94, 127,  73, NULL,  4),
  (5, '2026-09-25 11:00:00', 18, 98, 116, NULL, 36.2,  0),
  (5, '2026-09-26 06:00:00', 19, 97, 112,  64, 36.4,  0),
  (5, '2026-09-27 00:00:00', 18, 98, 118,  69, 36.5,  0),
  (6, '2026-09-25 10:00:00', 13, 94, 124,  83, 36.2,  1),
  (6, '2026-09-26 04:00:00', 15, 93, 124,  82, 36.3,  2),
  (6, '2026-09-26 21:00:00', 15, 95, 129,  76, 36.4,  1);
