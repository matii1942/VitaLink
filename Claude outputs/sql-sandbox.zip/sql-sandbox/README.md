# SQL sandbox — MySQL y PostgreSQL, al lado

Dos bases de datos con **la misma tabla y los mismos datos**, para que escribas
la misma consulta dos veces y veas exactamente dónde se separan.

Los datos son inventados: ocho pacientes, ocho internaciones, quince
observaciones. Ningún registro clínico real, igual que en VitaLink.

## Arrancar

```powershell
cd C:\Users\Mati\Desktop\sql-sandbox
docker compose up -d
docker compose ps
```

La primera vez tarda un minuto largo: baja las dos imágenes. Cuando las dos
digan `healthy`, están listas.

## Entrar a cada una

```powershell
# PostgreSQL
docker compose exec postgres psql -U sandbox -d sandbox

# MySQL
docker compose exec mysql mysql -u sandbox -psandbox sandbox
```

Adentro de `psql`:

| Comando | Qué hace |
| --- | --- |
| `\dt` | Listar las tablas |
| `\d observation` | Ver las columnas de una tabla |
| `\x` | Alternar la vista vertical (útil con filas anchas) |
| `\q` | Salir |

Adentro de `mysql`:

| Comando | Qué hace |
| --- | --- |
| `SHOW TABLES;` | Listar las tablas |
| `DESCRIBE observation;` | Ver las columnas de una tabla |
| `\G` al final en vez de `;` | Vista vertical |
| `exit` | Salir |

Ya se nota la primera diferencia: PostgreSQL tiene comandos propios del
cliente que empiezan con barra invertida; MySQL usa sentencias SQL
(Structured Query Language) normales para lo mismo.

## Apagar

```powershell
docker compose down      # las apaga, conserva los datos
docker compose down -v   # las apaga y BORRA los datos
```

Usá `down -v` cuando cambies algo en `init-postgres/` o `init-mysql/`: esos
archivos sólo se ejecutan cuando la base arranca **vacía**. Si el volumen
sigue existiendo, la base ya no está vacía y tus cambios no se aplican — es
el error que más tiempo hace perder con Docker.

Y acordate de tu propia regla: cuando termines de practicar, `down`. Son dos
bases de datos comiéndote memoria por nada.

## Qué hay adentro

```
docker-compose.yml          las dos bases, con healthcheck
init-postgres/01-schema.sql el esquema y los datos, dialecto PostgreSQL
init-mysql/01-schema.sql    el mismo esquema y los mismos datos, dialecto MySQL
EJERCICIOS.md               diez ejercicios, con las soluciones al final
```

Leé los dos archivos de esquema en paralelo antes de empezar. Las diferencias
están marcadas con `DIFERENCIA` y numeradas igual en los dos.

## Una nota honesta sobre la verificación

Todas las consultas de `EJERCICIOS.md` fueron ejecutadas antes de dártelas: el
lado PostgreSQL contra un PostgreSQL 16 real, y el lado MySQL contra un
MariaDB 10.11, que es el motor compatible que tenía a mano — no había Docker
donde lo armé.

MariaDB y MySQL son casi iguales, pero **no** idénticos, y hay dos ejercicios
donde eso importa. Están marcados en el texto. Cuando los corras vos, vas a
estar usando MySQL 8 de verdad, así que si un resultado no coincide con lo que
dice el ejercicio, el que tiene razón sos vos: anotalo.
